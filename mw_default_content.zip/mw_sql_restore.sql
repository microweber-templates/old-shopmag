
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('1','SAINT LAURENT','','4','content','2015-01-20 14:43:50','2015-01-20 14:43:45','650','','6c1787094bbccc24a343f133dea74eee27797751','2','','0','','','1','W10='); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('2','SAINT LAURENT','','4','content','2015-01-20 14:44:57','2015-01-20 14:44:57','650','','de2f02349ef3a52cbe78e4a58d8da9fcff4be910','1','','0','','','0','eyJNYXRlcmlhbCI6IkxlYXRoZXIifQ=='); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('3','SAINT LAURENT','','4','content','2015-01-20 14:45:37','2015-01-20 14:45:37','650','','4d9a8570b462c57edbba200dd107891e6db40bb9','1','','0','','','2','eyJNYXRlcmlhbCI6IkxlYXRoZXIifQ=='); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('4','SAINT LAURENT','','4','content','2015-01-20 16:03:24','2015-01-20 16:03:21','650','','4d9a8570b462c57edbba200dd107891e6db40bb9','2','','0','','','2','W10='); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('1','2015-01-20 14:21:00','2015-01-20 13:50:14','1','1','category','Bags','2','','','content','0','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('2','2015-01-20 14:19:54','2015-01-20 14:19:54','1','1','category','Women','0','','','content','3','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('3','2015-01-20 14:29:58','2015-01-20 14:29:58','1','1','category','Men','0','','','content','3','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('4','2015-01-20 14:30:25','2015-01-20 14:30:25','1','1','category','Shoes','3','','','content','0','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,parent_id,description,content,rel_type,rel_id,position,is_deleted,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,categories_content_type,categories_silo_keywords) VALUES('5','2015-01-20 14:55:01','2015-01-20 14:54:48','1','1','category','Fashion','0','','','content','6','0','0','','0','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('1','2','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('2','1','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('3','3','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('4','4','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('5','5','content','7'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments (id,rel_type,rel_id,updated_at,created_at,created_by,edited_by,comment_name,comment_body,comment_email,comment_website,is_moderated,from_url,comment_subject,is_new,send_email,session_id) VALUES('1','content','7','2015-01-20 18:06:13','2015-01-20 18:06:13','','','Anonimous','Great post! This is my first comment on this website!','comments-mw@mailinator.com','comments.microweber.com','','http://shopmag-content.microweber.com/versace','','','','6c1787094bbccc24a343f133dea74eee27797751'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('2','2015-02-09 16:12:03','2015-01-08 15:57:32','','2','2','page','home','','HOME','0','','','','-1','','','1','1','0','0','0','','0','','static','','','','','index.php','','','default','4603d96ee85f030a3d224ea41a800e6b4150fb5c','2015-01-08 15:58:24'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('3','2015-01-26 14:38:16','2015-01-20 13:49:49','','1','2','page','shop','','SHOP','0','','','','-2','','','1','0','0','1','0','','','','dynamic','','','','','layouts__shop_with_sidebar.php','','','default','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','2015-01-26 14:38:16'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('4','2015-01-20 14:26:06','2015-01-20 14:25:31','','1','1','product','saint-laurent','','SAINT LAURENT','3','','','','2','','','1','0','0','0','0','','0','','','','','','','inherit','','','','6c1787094bbccc24a343f133dea74eee27797751','2015-01-20 14:25:31'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('5','2015-01-26 14:38:16','2015-01-20 14:34:00','','1','2','product','men-shoes-velour','','Men Shoes Velour','3','','','','1','','','1','0','0','0','0','','0','','','','','','','inherit','','','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','2015-01-20 14:34:00'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('6','2015-01-20 18:30:02','2015-01-20 14:47:19','','1','1','page','-20150120162327','','MAGAZINE','0','','','','-3','','','1','0','0','0','0','','0','','dynamic','','','','','layouts__blog_with_sidebar.php','','','default','e7ae75703fa9d458546ef2e44e005ed2d9346300','2015-01-20 17:57:04'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('7','2015-01-20 17:19:00','2015-01-20 15:15:17','','1','1','post','versace','','Versace 1','6','','','','0','
                            <p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;"><br></p>
<p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;">Versace, Versace, Medusa head on me like I&rsquo;m &rsquo;luminati This is a gated community, please get the fuck off the property Rap must be changin&rsquo; cause I&rsquo;m at the top and ain&rsquo;t no one on top of me Niggas be wantin&rsquo; a verse for a verse, but man that&rsquo;s not a swap to me Drownin&rsquo; in compliments, pool in the backyard that look like Metropolis I think I&rsquo;m sellin&rsquo; a million first week, man I guess I&rsquo;m a optimist Born in Toronto but sometimes I feel like Atlanta adopted us What the fuck is you talkin&rsquo; &rsquo;bout? Saw this shit comin&rsquo; like I had binoculars Boy, Versace, Versace, we stay at the mansion when we in Miami The pillows&rsquo; Versace, the sheets are Versace, I just won a Grammy I&rsquo;ve been so quiet,</p>
<p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;"><br></p>
<p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;"> I got the world like "What the fuck is he plannin&rsquo;?" Just make sure that you got a back up plan cause that shit might come in handy Started a label, the album is comin&rsquo; September, just wait on it This year I&rsquo;m eatin&rsquo; your food and my table got so many plates on it Hundred inch TV at my house,</p>
<p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;"><br></p>
<p id="row_1407943535910" class="element" align="justify" style="font-family: &rsquo;Source Sans Pro&rsquo;, sans-serif; font-size: 15px; line-height: 24.6399993896484px;">I sit back like "damn I look great on it" I do not fuck with your new shit, my nigga, don&rsquo;t ask for my take on it Speakin&rsquo; in lingo, man this for my nigga that trap out the bando This for my niggas that call <span style="line-height: 1.85;">up Fernando to move a piano Fuck all your feelin&rsquo;s cause business is business, its strictly financial I&rsquo;m always the first one to get it, man that&rsquo;s how you lead by example Versace, Versace, Versace, Versace, Versace, Versace Word to New York cause the Dyckman and Heights girls are callin&rsquo; me "Papi" I&rsquo;m all on the low, take a famous girl out where there&rsquo;s no paparazzi I&rsquo;m tryna give Halle Berry a baby and no one can stop me</span></p>
                          ','','1','0','0','0','0','','0','','post','','','','','inherit','','','','6c1787094bbccc24a343f133dea74eee27797751','2015-01-20 15:15:17'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('8','2015-01-26 12:55:39','2015-01-20 17:57:04','','1','2','page','contacts','','CONTACTS','0','','','','-4','
      <div class="item-box pad element" id="row_1421778525371">
          <h1 align="center" class="element" id="row_1421778525231">Contact us</h1>
          <p align="center" class="element" id="row_1421778525212">
              Nam vel ex gravida orci rutrum varius et sit amet neque. Duis eget tincidunt dolor, vel auctor neque. Praesent odio risus, sagittis fermentum quam et, ultricies vulputate enim.
              Sed congue placerat felis, quis viverra eros efficitur et. Pellentesque aliquam sed mauris vel sodales.
          </p>
          </div>
          <br><module class="module module module-google-maps " data-mw-title="Google Maps" id="module-google-maps3894429358" data-type="google_maps"></module><br><div class="item-box pad element" id="row_1421778525818"><div class="mw-row" style="height: auto;" id="row_1421778525822">
              <div class="mw-col" style="width: 48%; height: auto;">
                <div class="mw-col-container">
                  <module class="module module-contact-form" data-mw-title="Contact form" id="module-contact-form1996028020" data-type="contact_form"></module>
</div>
              </div>
              <div class="mw-col" style="width: 4%; height: auto;">
                <div class="mw-col-container">

                </div>
              </div>
              <div class="mw-col" style="width: 48%; height: auto;">
                <div class="mw-col-container">
                    <h2 class=" element">Address</h2>
                  <ul class="mw-list">
<li>
<span class="mw-icon-map"></span>Sofia 1700, Bulgaria, My place #10 str. , bl. B, fl. 3</li>
                    <li>
<span class="mw-icon-app-telephone"></span>+1 234-567-890</li>
                  </ul>
<hr>
<h2 class=" element" id="row_1421778525963">Follow Us</h2>
                  <ul class="mw-list">
<li>
                        <a href="https://facebook.com/Microweber"><span class="mw-icon-facebook"></span>https://facebook.com/Microweber</a>
                      </li>
                      <li>
                        <a href="https://twitter.com/Microweber"><span class="mw-icon-twitter"></span>https://twitter.com/Microweber</a>
                      </li>
                      <li>
                        <a href="https://plus.google.com/+Microweber/"><span class="mw-icon-googleplus"></span>https://plus.google.com/+Microweber/</a>
                      </li>
                  </ul>
</div>
              </div>
          </div></div>

    ','','1','0','0','0','0','','0','','static','','','','','layouts__contacts.php','','','default','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','2015-01-20 17:57:04'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('9','2015-01-26 13:15:52','2015-01-26 11:10:29','','2','2','page','terms-and-conditions','','TERMS AND CONDITIONS','0','','','','-5','
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
<p class="element" id="row_1422270632985"><span><br></span></p>
<p class="element" id="row_1422270632985">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&rsquo;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
<p class="element" id="row_1422270632985"><br></p>
<p class="element" id="row_1422270632985">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &rsquo;Content here, content here&rsquo;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &rsquo;lorem ipsum&rsquo; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
<p class="element" id="row_1422270632985"><br></p>
<p class="element" id="row_1422270632985"> </p>
<p class="element" id="row_1422270632985">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
<p class="element" id="row_1422270632985"><br></p>
<p class="element" id="row_1422270632985">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
<p class="element" id="row_1422270632985"><br></p>
<p class="element" id="row_1422270632985">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&rsquo;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&rsquo;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
<p class="element" id="row_1422270632985"><br></p>
    ','','1','0','0','0','0','','0','','static','','','','','inherit','','','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','2015-01-26 11:31:32'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('10','2015-01-26 13:17:15','2015-01-26 11:31:32','','2','2','page','return-policy-amp-shipping','','RETURN POLICY','0','','','','-6','
      <p class="element" id="row_1422270845389"><br></p>
<p class="element" id="row_1422270845389"><span data-mce-style="font-weight: 400;">You may return most new, unopened items within 30 days of delivery for a full refund. We&rsquo;ll also pay the return shipping costs if the return is a result of our error (you received an incorrect or defective item, etc.).<br><br>You should expect to receive your refund within four weeks of giving your package to the return shipper, however, in many cases you will receive a refund more quickly. This time period includes the transit time for us to receive your return from the shipper (5 to 10 business days), the time it takes us to process your return once we receive it (3 to 5 business days), and the time it takes your bank to process our refund request (5 to 10 business days).<br><br>If you need to return an item, please <a href="https://example.com/contact-us/" data-mce-href="https://store-a6a0olhl.mybigcommerce.com/contact-us/" target="_self"><b>Contact U</b>s</a> with your order number and details about the product you would like to return. We will respond quickly with instructions for how to return items from your order.<br><br></span><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif"><span>Shipping</span></font><span data-mce-style="font-weight: 400;"><span data-mce-style="font-style: normal;"><br><br></span>We can ship to virtually any address in the world. Note that there are restrictions on some products, and some products cannot be shipped to international destinations.<br><br>When you place an order, we will estimate shipping and delivery dates for you based on the availability of your items and the shipping options you choose. Depending on the shipping provider you choose, shipping date estimates may appear on the shipping quotes page.<br><br>Please also note that the shipping rates for many items we sell are weight-based. The weight of any such item can be found on its detail page. To reflect the policies of the shipping companies we use, all weights will be rounded up to the next full pound.</span></p>
    ','','1','0','0','0','0','','0','','static','','','','','inherit','','','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','2015-01-26 11:31:32'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','qty','nolimit','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','sku','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','shipping_weight','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','shipping_width','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','shipping_height','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','shipping_depth','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2015-01-26 14:38:16','2015-01-26 14:38:16','2','2','5','additional_shipping_cost','','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','content','5'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('1','2015-01-20 13:42:43','2015-01-20 13:42:43','1','1','home_2','6','content','
        <div class="mw-row picture-with-categories-layout" style="height: auto;" id="row_1421761295639">
    <div class="mw-col" style="width: 60%; height: auto;">
      <div class="mw-col-container">
        <img src="{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/ShopMag_Defaulth_install_content.jpg" class="element" alt="" width="100%" id="row_1421761295635" style="height: auto;">
</div>
    </div>
    <div class="mw-col" style="width: 40%; height: auto;">
      <div class="mw-col-container">
        <div class="item-box pad2 element"><module class=" module module-content-categories " id="content_categories_203939723454be5b0d3973c" data-type="content_categories"></module></div>
      </div>
    </div>
</div>        <p class="element"><br></p>
        <div class="mw-row picture-with-categories-layout" style="height: auto;" id="row_1421761295618">
    <div class="mw-col" style="width: 60%; height: auto;">
      <div class="mw-col-container">
        <img src="{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/banner_2.jpg" class="element" alt="" width="100%" id="row_1421761296223" style="height: auto;">
</div>
    </div>
    <div class="mw-col" style="width: 40%; height: auto;">
      <div class="mw-col-container">
        <div class="item-box pad2 element"><module class=" module module-content-categories " id="content_categories_119690042354be5b0d39832" data-type="content_categories"></module></div>
      </div>
    </div>
</div>  '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('3','2015-01-20 15:15:56','2015-01-20 15:15:56','1','1','content','7','title','Page Title'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('5','2015-01-20 16:54:19','2015-01-20 16:54:19','1','1','content','5','title','Men Shoes Velour 1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('6','2015-01-20 17:18:20','2015-01-20 17:18:20','1','1','content','7','comments','
                          <module class="module module-comments" id="module-comments2538236660" data-mw-title="Comments" data-type="comments" data-template="default" data-content-id="7"></module>
                        '); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','module','footer_contact_form','0','email','Email','email','2015-01-08 15:51:51','2015-01-08 15:51:51','0','0','548666071136c2c52111790f60976f223fc34441','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','content','2','','price','price','price','2015-01-20 13:50:27','2015-01-20 13:50:27','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','content','4','','price','price','price','2015-01-20 14:23:46','2015-01-20 14:19:28','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','content','4','','dropdown','Material','material','2015-01-20 14:24:51','2015-01-20 14:24:05','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','content','4','','radio','Color','color','2015-01-20 14:25:25','2015-01-20 14:25:05','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','content','5','0','price','price','price','2015-01-26 14:37:16','2015-01-20 14:30:39','1','2','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('7','content','5','2','dropdown','Choose Size','choose-size','2015-01-20 14:33:57','2015-01-20 14:33:11','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('8','module','shipping-info-module-shop-shipping-gateways-country557478767','0','address','Address','address','2015-01-20 15:48:35','2015-01-20 15:48:35','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('9','module','shipping-info-module-shop-shipping-gateways-country55747876754be78d380a83','0','address','Address','address','2015-01-20 15:48:35','2015-01-20 15:48:35','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('10','module','shipping-info-module-shop-shipping-gateways-country55747876754be78d386448','0','address','Address','address','2015-01-20 15:48:35','2015-01-20 15:48:35','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('11','module','shipping-info-module-shop-shipping-gateways-country55747876754be78d38b186','0','address','Address','address','2015-01-20 15:48:35','2015-01-20 15:48:35','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('12','module','shipping-info-module-shop-shipping-gateways-country55747876754be78d393000','0','address','Address','address','2015-01-20 15:48:35','2015-01-20 15:48:35','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('13','module','shipping-info-module-shop-shipping-gateways-country2450837755','0','address','Address','address','2015-01-20 17:19:47','2015-01-20 17:19:47','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('14','module','shipping-info-module-shop-shipping-gateways-country55747876754be9463aa379','0','address','Address','address','2015-01-20 17:46:11','2015-01-20 17:46:11','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('15','module','shipping-info-module-shop-shipping-gateways-country55747876754be9463b7d93','0','address','Address','address','2015-01-20 17:46:11','2015-01-20 17:46:11','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('16','module','shipping-info-module-shop-shipping-gateways-country55747876754be9463c1e70','0','address','Address','address','2015-01-20 17:46:11','2015-01-20 17:46:11','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('17','module','shipping-info-module-shop-shipping-gateways-country55747876754be9463c9f5c','0','address','Address','address','2015-01-20 17:46:11','2015-01-20 17:46:11','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('18','module','shipping-info-module-shop-shipping-gateways-country55747876754be947e76cda','0','address','Address','address','2015-01-20 17:46:38','2015-01-20 17:46:38','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('19','module','shipping-info-module-shop-shipping-gateways-country55747876754be947e7ccbe','0','address','Address','address','2015-01-20 17:46:38','2015-01-20 17:46:38','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('20','module','shipping-info-module-shop-shipping-gateways-country55747876754be947e81d31','0','address','Address','address','2015-01-20 17:46:38','2015-01-20 17:46:38','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('21','module','shipping-info-module-shop-shipping-gateways-country55747876754be947eb2518','0','address','Address','address','2015-01-20 17:46:38','2015-01-20 17:46:38','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('22','module','module-contact-form1996028020','0','name','Name','name','2015-01-20 17:56:51','2015-01-20 17:56:51','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('23','module','module-contact-form1996028020','2','text','text','text','2015-01-20 17:58:19','2015-01-20 17:57:52','1','1','6c1787094bbccc24a343f133dea74eee27797751','eyJhc190ZXh0X2FyZWEiOlsiMSJdfQ==','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('24','module','module-contact-form1996028020','1','email','email','email','2015-01-20 17:58:04','2015-01-20 17:58:04','1','1','6c1787094bbccc24a343f133dea74eee27797751','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('25','content','5','','price','price','price','2015-01-26 14:32:00','2015-01-26 14:32:00','2','2','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('26','content','5','1','price','price 2','price-2','2015-01-26 14:37:34','2015-01-26 14:37:25','2','2','070ebb773178f8ba5ea28c9ab2cef48c4a99ac68','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','2','0','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','3','650','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','4','Leather','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('4','4','Artificial Leather','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('5','5','Black','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('6','5','White','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('7','5','Cold','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('8','6','80','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('9','7','36','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('10','7','37','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('11','7','38 - US','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('12','7','40','3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('13','23','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('14','25','0','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('15','26','34','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('1','2015-01-20 14:23:13','2015-01-20 14:23:13','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','3','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/384649_bk_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('2','2015-01-20 14:23:14','2015-01-20 14:23:14','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','4','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/384649_cu_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('3','2015-01-20 14:23:16','2015-01-20 14:23:16','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','2','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/384649_fr_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('4','2015-01-20 14:23:17','2015-01-20 14:23:17','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','0','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/384649_in_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('5','2015-01-20 14:23:18','2015-01-20 14:23:18','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','1','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/384649_ou_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('6','2015-01-20 14:23:19','2015-01-20 14:23:19','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','4','picture','5','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/SAINT_LAURENT.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('7','2015-01-20 14:31:40','2015-01-20 14:31:40','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','3','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_bk_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('8','2015-01-20 14:31:43','2015-01-20 14:31:43','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','4','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_cu_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('9','2015-01-20 14:31:44','2015-01-20 14:31:44','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','5','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_e1_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('10','2015-01-20 14:31:45','2015-01-20 14:31:45','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','1','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_e2_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('11','2015-01-20 14:31:46','2015-01-20 14:31:46','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','2','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_fr_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('12','2015-01-20 14:31:47','2015-01-20 14:31:47','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','0','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_in_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('13','2015-01-20 14:31:48','2015-01-20 14:31:48','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','5','picture','6','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/457875_mrp_ou_xl.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('14','2015-01-20 15:14:46','2015-01-20 15:14:46','1','1','6c1787094bbccc24a343f133dea74eee27797751','content','7','picture','9999999','','','','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/Home_v1.jpg'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('1','header_menu','menu','','','','','2015-01-08 15:51:51','2015-01-08 15:51:51','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('2','footer_menu','menu','','','','','2015-01-08 15:51:53','2015-01-08 15:51:53','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('3','footer_menu_about','menu','','','','','2015-01-08 15:51:55','2015-01-08 15:51:55','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('13','','menu_item','1','1','','999999','2015-01-20 15:21:09','2015-01-20 15:21:09','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('5','','menu_item','1','2','','0','2015-01-08 15:57:32','2015-01-08 15:57:32','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('7','','menu_item','1','3','','1','2015-01-20 14:18:29','2015-01-20 14:18:29','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('8','','menu_item','2','2','','0','2015-01-20 14:18:52','2015-01-20 14:18:52','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('9','','menu_item','2','3','','1','2015-01-20 14:18:56','2015-01-20 14:18:56','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('10','','menu_item','2','1','','999999','2015-01-20 14:53:23','2015-01-20 14:53:23','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('46','','menu_item','2','8','','3','2015-01-20 18:29:13','2015-01-20 18:29:13','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('43','','menu_item','1','6','','999999','2015-01-20 16:30:01','2015-01-20 16:30:01','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('45','','menu_item','1','8','','999999','2015-01-20 17:57:04','2015-01-20 17:57:04','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('47','','menu_item','2','6','','2','2015-01-20 18:30:02','2015-01-20 18:30:02','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('48','','menu_item','2','9','','999999','2015-01-26 11:13:09','2015-01-26 11:13:09','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('49','','menu_item','2','10','','999999','2015-01-26 11:33:25','2015-01-26 11:33:25','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content) VALUES('1','2015-01-20 18:06:13','2015-01-20 18:06:13','0','0','7','content','','','comments','You have new comment','New comment is posted on {SITE_URL}versace','Great post! This is my first comment on this website!'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2015-01-08 15:51:26','2015-01-08 15:51:26','current_template','shopmag','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2015-01-20 13:43:23','2015-01-20 13:43:23','logoimage','{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/Logo_v12.png','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','2015-01-20 13:43:23','2015-01-20 13:43:23','size','auto','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','2015-01-20 13:47:17','2015-01-20 13:44:00','settings','{"0":{"primaryText":"Magic Slider","secondaryText":"THIS WEEK&rsquo;S OFFER 80% OFF!","url":"","skin":"default","images":"{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/1.jpg,{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/2.jpg"}}','','','','homeslider','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','2015-01-20 14:18:50','2015-01-20 14:18:50','menu_name','footer_menu','','','','footer-menu','','','','','menu',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','2015-01-20 14:34:46','2015-01-20 14:34:46','fromcategory','3','','','','content_categories_119690042354be5b0d39832','','','','','content_categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2015-01-20 14:34:54','2015-01-20 14:34:54','fromcategory','2','','','','content_categories_203939723454be5b0d3973c','','','','','content_categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2015-01-20 16:53:27','2015-01-20 14:49:13','data-page-id','0','','','','module-posts2171858572','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2015-01-20 14:50:24','2015-01-20 14:50:11','data-category-id','0','','','','module-posts2171858572','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2015-01-20 15:49:28','2015-01-20 15:45:37','paypalexpress_testmode','y','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2015-01-20 17:19:59','2015-01-20 15:45:45','payment_gw_shop/payments/gateways/paypal','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2015-01-20 15:49:47','2015-01-20 15:45:50','pay_on_delivery_show_msg','n','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('13','2015-01-20 15:46:09','2015-01-20 15:46:09','pay_on_delivery_msg','You will need to pay this order on delivery! ','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('14','2015-01-20 15:49:48','2015-01-20 15:46:09','payment_gw_shop/payments/gateways/pay_on_delivery','0','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('15','2015-01-20 15:46:13','2015-01-20 15:46:13','shop_require_terms','1','','','','website','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('16','2015-01-20 15:46:34','2015-01-20 15:46:24','payment_currency_rate','','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('17','2015-01-20 17:19:47','2015-01-20 15:48:25','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('18','2015-01-20 16:22:33','2015-01-20 16:22:33','facebook_enabled','y','','','','sidebarsociallinks','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('19','2015-01-20 16:22:35','2015-01-20 16:22:35','twitter_enabled','y','','','','sidebarsociallinks','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('20','2015-01-20 16:22:36','2015-01-20 16:22:36','googleplus_enabled','y','','','','sidebarsociallinks','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('21','2015-01-20 16:22:36','2015-01-20 16:22:36','pinterest_enabled','y','','','','sidebarsociallinks','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('22','2015-01-20 16:22:37','2015-01-20 16:22:37','youtube_enabled','y','','','','sidebarsociallinks','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('23','2015-01-20 17:27:22','2015-01-20 17:27:12','display_comments_from','current','','','','module-comments2538236660','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('24','2015-01-20 17:27:19','2015-01-20 17:27:16','display_comments_from_which_post','current_post','','','','module-comments2538236660','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('25','2015-01-20 17:31:07','2015-01-20 17:31:07','enable_comments','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('26','2015-01-20 17:31:10','2015-01-20 17:31:10','avatar_enabled','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('27','2015-01-20 17:31:11','2015-01-20 17:31:11','avatar_style','3','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('28','2015-01-20 17:31:14','2015-01-20 17:31:14','set_paging','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('29','2015-01-20 17:31:21','2015-01-20 17:31:19','paging','15','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('30','2015-01-20 17:31:29','2015-01-20 17:31:24','require_moderation','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('31','2015-01-20 17:31:40','2015-01-20 17:31:34','email_on_new_comment','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('32','2015-01-20 17:32:12','2015-01-20 17:31:57','email_on_new_comment_value','example-mw@mailinator.com','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('33','2015-01-20 17:59:44','2015-01-20 17:59:06','data-template','default','','','','module-contact-form1996028020','','','','','contact_form',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('34','2015-01-20 18:32:09','2015-01-20 18:31:23','shopmagdata','{"color":"","layout":"","fontfamily":""}','','','','mw-template-shopmag','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('35','2015-02-24 14:29:39','2015-02-24 14:29:39','fromcategory','2','','','','home_category_1','','','','','content_categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('36','2015-02-24 14:29:57','2015-02-24 14:29:53','fromcategory','3','','','','home_category_2','','','','','content_categories',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('37','2015-02-24 14:32:41','2015-02-24 14:32:37','settings','{"0":{"primaryText":"Magic Slider","secondaryText":"Nunc blandit malesuada magna nec luctus.","seemoreText":"See more","url":"","skin":"backgrounded","images":"{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/slide_1.jpg"}}','','','','homeslider_1','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('38','2015-02-24 14:33:05','2015-02-24 14:32:55','settings','{"0":{"primaryText":"Magic Slider","secondaryText":"Nunc blandit malesuada magna nec luctus.","seemoreText":"See more","url":"","skin":"backgrounded","images":"{SITE_URL}userfiles/media/shopmag-content-microweber-com/uploaded/slide_2.jpg"}}','','','','homeslider_2','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */





